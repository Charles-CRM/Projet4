tinymce.init({
  selector: '#tinymceTextarea',
  height: 500,
  menubar: false,
  toolbar: 'undo redo |  formatselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist | removeformat',
  content_css: './public/css/chapter-inner-style.css'
});